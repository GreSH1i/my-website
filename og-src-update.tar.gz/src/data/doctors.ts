import type { Locale } from '../i18n/utils';

export interface DoctorData {
  slug: string;
  photo: string;
  name: { uk: string; ru: string; en: string };
  title: { uk: string; ru: string; en: string };
  position: { uk: string; ru: string; en: string };
  bio: { uk: string; ru: string; en: string };
  specializations: { uk: string[]; ru: string[]; en: string[] };
  experience: number;
  certificates: string[];
  services: string[];
}

export const doctors: DoctorData[] = [
  {
    slug: 'serdyuk',
    photo: '/images/doctors/serdyuk-profile.png',
    name: { uk: 'Сердюк Валерій Миколайович', ru: 'Сердюк Валерий Николаевич', en: 'Valeriy Serdyuk' },
    title: { uk: 'Професор, доктор медичних наук, Заслужений лікар України', ru: 'Профессор, доктор медицинских наук, Заслуженный врач Украины', en: 'Professor, Doctor of Medical Sciences, Honored Doctor of Ukraine' },
    position: { uk: 'Офтальмолог-хірург, керівник центру', ru: 'Офтальмолог-хирург, руководитель центра', en: 'Ophthalmologist-Surgeon, Center Director' },
    bio: {
      uk: 'Валерій Миколайович Сердюк — доктор медичних наук, професор, провідний офтальмолог-хірург з більш ніж 30-річним досвідом. Засновник та керівник офтальмологічного центру Ophthalmology-group. Виконав понад 15 000 операцій на очах. Спеціалізується на мікрохірургії катаракти, кератопластиці, лікуванні глаукоми та складних патологій сітківки. Автор понад 100 наукових публікацій, має 12 патентів на винаходи в офтальмології.',
      ru: 'Валерий Николаевич Сердюк — доктор медицинских наук, профессор, ведущий офтальмолог-хирург с более чем 30-летним опытом. Основатель и руководитель офтальмологического центра Ophthalmology-group. Выполнил более 15 000 операций на глазах. Специализируется на микрохирургии катаракты, кератопластике, лечении глаукомы и сложных патологиях сетчатки. Автор более 100 научных публикаций, имеет 12 патентов на изобретения в офтальмологии.',
      en: 'Valeriy Serdyuk, MD, PhD, Professor — a leading ophthalmologist-surgeon with over 30 years of experience. Founder and director of the Ophthalmology-group center. Performed over 15,000 eye surgeries. Specializes in cataract microsurgery, keratoplasty, glaucoma treatment, and complex retinal pathologies. Author of over 100 scientific publications with 12 patents in ophthalmology.',
    },
    specializations: {
      uk: ['Мікрохірургія катаракти', 'Кератопластика', 'Лікування глаукоми', 'Патології сітківки', 'Блефаропластика'],
      ru: ['Микрохирургия катаракты', 'Кератопластика', 'Лечение глаукомы', 'Патологии сетчатки', 'Блефаропластика'],
      en: ['Cataract Microsurgery', 'Keratoplasty', 'Glaucoma Treatment', 'Retinal Pathology', 'Blepharoplasty'],
    },
    experience: 30,
    certificates: [
      '/images/doctors/serdyuk1.jpeg',
      '/images/doctors/serdyuk2.jpeg',
      '/images/doctors/serdyuk3.jpeg',
      '/images/doctors/serdyuk4.png',
      '/images/doctors/serdyuk5.jpg',
      '/images/doctors/serdyuk6.jpeg',
      '/images/doctors/serdyuk7.jpeg',
      '/images/doctors/serdyuk8.jpg',
      '/images/doctors/serdyuk9.jpeg',
      '/images/doctors/serdyuk10.jpeg',
      '/images/doctors/serdyuk11.jpg',
      '/images/doctors/serdyuk12.jpeg',
      '/images/doctors/serdyuk13.jpeg',
      '/images/doctors/serdyuk14.jpeg',
    ],
    services: ['diagnostyka-zoru', 'katarakta', 'glaukoma', 'keratoplastyka', 'blefaroplastyka'],
  },
  {
    slug: 'stokova',
    photo: '/images/doctors/stokova-profile.png',
    name: { uk: 'Стокова Лілія Володимирівна', ru: 'Стокова Лилия Владимировна', en: 'Liliia Stokova' },
    title: { uk: 'Лікар-офтальмолог', ru: 'Врач-офтальмолог', en: 'Ophthalmologist' },
    position: { uk: 'Офтальмолог', ru: 'Офтальмолог', en: 'Ophthalmologist' },
    bio: {
      uk: 'Лілія Володимирівна Стокова — лікар-офтальмолог. Спеціалізується на діагностиці та консервативному лікуванні очних захворювань.',
      ru: 'Лилия Владимировна Стокова — врач-офтальмолог. Специализируется на диагностике и консервативном лечении глазных заболеваний.',
      en: 'Liliia Stokova — ophthalmologist. Specializes in diagnostics and conservative treatment of eye diseases.',
    },
    specializations: {
      uk: ['Діагностика зору', 'Консервативне лікування'],
      ru: ['Диагностика зрения', 'Консервативное лечение'],
      en: ['Vision Diagnostics', 'Conservative Treatment'],
    },
    experience: 5,
    certificates: [],
    services: ['diagnostyka-zoru', 'icare-monytoryng'],
  },
  {
    slug: 'getman',
    photo: '/images/doctors/getman-profile.png',
    name: { uk: 'Гетьман Юлія Валентинівна', ru: 'Гетьман Юлия Валентиновна', en: 'Yulia Getman' },
    title: { uk: 'Лікар-офтальмолог вищої категорії', ru: 'Врач-офтальмолог высшей категории', en: 'Ophthalmologist, Highest Category' },
    position: { uk: 'Офтальмолог-діагност', ru: 'Офтальмолог-диагност', en: 'Ophthalmologist-Diagnostician' },
    bio: {
      uk: 'Юлія Валентинівна Гетьман — лікар-офтальмолог вищої категорії з 21-річним досвідом роботи на сучасному діагностичному обладнанні. Проводить комплексну діагностику зору, включаючи ОКТ-дослідження, периметрію, біометрію ока. Має досвід підбору контактних лінз та консервативного лікування очних захворювань.',
      ru: 'Юлия Валентиновна Гетьман — врач-офтальмолог высшей категории с 21-летним опытом работы на современном диагностическом оборудовании. Проводит комплексную диагностику зрения, включая ОКТ-исследования, периметрию, биометрию глаза. Имеет опыт подбора контактных линз и консервативного лечения глазных заболеваний.',
      en: 'Yulia Getman — ophthalmologist of the highest category with 21 years of experience working with modern diagnostic equipment. Performs comprehensive vision diagnostics including OCT studies, perimetry, and eye biometry. Experienced in contact lens fitting and conservative treatment of eye diseases.',
    },
    specializations: {
      uk: ['Комплексна діагностика зору', 'ОКТ-дослідження', 'Периметрія', 'Підбір контактних лінз'],
      ru: ['Комплексная диагностика зрения', 'ОКТ-исследования', 'Периметрия', 'Подбор контактных линз'],
      en: ['Comprehensive Vision Diagnostics', 'OCT Studies', 'Perimetry', 'Contact Lens Fitting'],
    },
    experience: 21,
    certificates: [],
    services: ['diagnostyka-zoru', 'icare-monytoryng'],
  },
  {
    slug: 'ysaev',
    photo: '/images/doctors/ysaev-profile.png',
    name: { uk: 'Ісаєв Олексій Андрійович', ru: 'Исаев Алексей Андреевич', en: 'Alexey Isaev' },
    title: { uk: 'Лікар-офтальмолог', ru: 'Врач-офтальмолог', en: 'Ophthalmologist' },
    position: { uk: 'Офтальмолог-хірург', ru: 'Офтальмолог-хирург', en: 'Ophthalmologist-Surgeon' },
    bio: {
      uk: 'Олексій Андрійович Ісаєв — лікар-офтальмолог-хірург, який спеціалізується на лікуванні захворювань сітківки та скловидного тіла. Виконує операції з лікування відшарування сітківки, діабетичної ретинопатії, макулярних патологій. Володіє методиками вітреоретинальної хірургії та лазерної коагуляції сітківки.',
      ru: 'Алексей Андреевич Исаев — врач-офтальмолог-хирург, специализирующийся на лечении заболеваний сетчатки и стекловидного тела. Выполняет операции по лечению отслоения сетчатки, диабетической ретинопатии, макулярных патологий. Владеет методиками витреоретинальной хирургии и лазерной коагуляции сетчатки.',
      en: 'Alexey Isaev — ophthalmologist-surgeon specializing in retinal and vitreous body diseases. Performs surgeries for retinal detachment, diabetic retinopathy, and macular pathologies. Skilled in vitreoretinal surgery and retinal laser coagulation techniques.',
    },
    specializations: {
      uk: ['Вітреоретинальна хірургія', 'Лазерна коагуляція сітківки', 'Лікування відшарування сітківки', 'Діабетична ретинопатія'],
      ru: ['Витреоретинальная хирургия', 'Лазерная коагуляция сетчатки', 'Лечение отслоения сетчатки', 'Диабетическая ретинопатия'],
      en: ['Vitreoretinal Surgery', 'Retinal Laser Coagulation', 'Retinal Detachment Treatment', 'Diabetic Retinopathy'],
    },
    experience: 10,
    certificates: [],
    services: ['diagnostyka-zoru', 'glaukoma'],
  },
  {
    slug: 'magdych',
    photo: '/images/doctors/magdych-profile.png',
    name: { uk: 'Магдич Костянтин Вікторович', ru: 'Магдыч Константин Викторович', en: 'Kostiantyn Magdych' },
    title: { uk: 'Офтальмохірург найвищої категорії', ru: 'Офтальмохирург высшей категории', en: 'Ophthalmosurgeon, Highest Category' },
    position: { uk: 'Офтальмолог-хірург', ru: 'Офтальмолог-хирург', en: 'Ophthalmologist-Surgeon' },
    bio: {
      uk: 'Костянтин Вікторович Магдич — лікар-офтальмолог-хірург з досвідом проведення операцій з видалення катаракти, лікування глаукоми та кератопластики. Має значний практичний досвід у застосуванні мініінвазивних хірургічних технік та імплантації преміальних інтраокулярних лінз.',
      ru: 'Константин Викторович Магдыч — врач-офтальмолог-хирург с опытом проведения операций по удалению катаракты, лечению глаукомы и кератопластике. Имеет значительный практический опыт в применении миниинвазивных хирургических техник и имплантации премиальных интраокулярных линз.',
      en: 'Kostiantyn Magdych — ophthalmologist-surgeon with experience in cataract removal, glaucoma treatment, and keratoplasty operations. Significant practical experience in minimally invasive surgical techniques and premium intraocular lens implantation.',
    },
    specializations: {
      uk: ['Хірургія катаракти', 'Лікування глаукоми', 'Кератопластика', 'Імплантація ІОЛ'],
      ru: ['Хирургия катаракты', 'Лечение глаукомы', 'Кератопластика', 'Имплантация ИОЛ'],
      en: ['Cataract Surgery', 'Glaucoma Treatment', 'Keratoplasty', 'IOL Implantation'],
    },
    experience: 12,
    certificates: ['/images/doctors/magdych-cert.jpg'],
    services: ['katarakta', 'glaukoma', 'keratoplastyka'],
  },
  {
    slug: 'yavorska',
    photo: '/images/doctors/yavorska-profile.png',
    name: { uk: 'Яворська Вікторія Русланівна', ru: 'Яворская Виктория Руслановна', en: 'Viktoriia Yavorska' },
    title: { uk: 'Лікар-офтальмолог', ru: 'Врач-офтальмолог', en: 'Ophthalmologist' },
    position: { uk: 'Дитячий офтальмолог', ru: 'Детский офтальмолог', en: 'Pediatric ophthalmologist' },
    bio: {
      uk: 'Вікторія Русланівна Яворська — лікар-офтальмолог. Спеціалізується на діагностиці та лікуванні захворювань ока.',
      ru: 'Виктория Руслановна Яворская — врач-офтальмолог. Специализируется на диагностике и лечении заболеваний глаза.',
      en: 'Viktoriia Yavorska — ophthalmologist. Specializes in diagnosis and treatment of eye diseases.',
    },
    specializations: {
      uk: ['Дитяча офтальмологія', 'Діагностика зору', 'Лікування очних захворювань'],
      ru: ['Детская офтальмология', 'Диагностика зрения', 'Лечение глазных заболеваний'],
      en: ['Pediatric Ophthalmology', 'Vision Diagnostics', 'Eye Disease Treatment'],
    },
    experience: 5,
    certificates: [],
    services: ['diagnostyka-zoru', 'dytiacha-oftalmologiya'],
  },
  {
    slug: 'kolomiyets',
    photo: '/images/doctors/kolomiyets-profile.jpg',
    name: { uk: 'Поліжак Микола Іванович', ru: 'Полижак Николай Иванович', en: 'Mykola Polizhak' },
    title: { uk: 'Лікар-офтальмолог', ru: 'Врач-офтальмолог', en: 'Ophthalmologist' },
    position: { uk: 'Вітреоретинальний хірург', ru: 'Витреоретинальный хирург', en: 'Vitreoretinal Surgeon' },
    bio: {
      uk: 'Микола Іванович Поліжак — вітреоретинальний хірург, спеціаліст з видалення сторонніх тіл при мінно-вибухових травмах ока. Має досвід проведення складних операцій на сітківці та скловидному тілі.',
      ru: 'Николай Иванович Полижак — витреоретинальный хирург, специалист по удалению инородных тел при минно-взрывных травмах глаза. Имеет опыт проведения сложных операций на сетчатке и стекловидном теле.',
      en: 'Mykola Polizhak — vitreoretinal surgeon specializing in foreign body removal from blast injury eye trauma. Experienced in complex retinal and vitreous body surgeries.',
    },
    specializations: {
      uk: ['Вітреоретинальна хірургія', 'Видалення сторонніх тіл ока', 'Мінно-вибухові травми', 'Хірургія сітківки'],
      ru: ['Витреоретинальная хирургия', 'Удаление инородных тел глаза', 'Минно-взрывные травмы', 'Хирургия сетчатки'],
      en: ['Vitreoretinal Surgery', 'Ocular Foreign Body Removal', 'Blast Injury Treatment', 'Retinal Surgery'],
    },
    experience: 6,
    certificates: [],
    services: ['diagnostyka-zoru', 'glaukoma'],
  },
  {
    slug: 'polizhak',
    photo: '/images/doctors/polizhak-profile.jpg',
    name: { uk: 'Коломієць Ілля Олегович', ru: 'Коломиец Илья Олегович', en: 'Illia Kolomiyets' },
    title: { uk: 'Лікар-офтальмолог', ru: 'Врач-офтальмолог', en: 'Ophthalmologist' },
    position: { uk: 'Ургентний лікар-офтальмолог', ru: 'Ургентный врач-офтальмолог', en: 'Emergency Ophthalmologist' },
    bio: {
      uk: 'Ілля Олегович Коломієць — ургентний лікар-офтальмолог. Надає невідкладну офтальмологічну допомогу, проводить первинну діагностику та консультування пацієнтів, визначає тактику подальшого обстеження й лікування.',
      ru: 'Илья Олегович Коломиец — ургентный врач-офтальмолог. Оказывает неотложную офтальмологическую помощь, проводит первичную диагностику и консультирование пациентов, определяет тактику дальнейшего обследования и лечения.',
      en: 'Illia Kolomiyets — emergency ophthalmologist. Provides urgent ophthalmological care, performs primary diagnostics and patient consultations, and determines the approach to further examination and treatment.',
    },
    specializations: {
      uk: ['Невідкладна офтальмологічна допомога', 'Первинна діагностика зору', 'Консультування пацієнтів'],
      ru: ['Неотложная офтальмологическая помощь', 'Первичная диагностика зрения', 'Консультирование пациентов'],
      en: ['Emergency Ophthalmological Care', 'Primary Vision Diagnostics', 'Patient Consultations'],
    },
    experience: 1,
    certificates: [],
    services: ['diagnostyka-zoru'],
  },
];

export function getDoctorBySlug(slug: string): DoctorData | undefined {
  return doctors.find((d) => d.slug === slug);
}
