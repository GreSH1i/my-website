// Розширений контент сторінок послуг (тексти від клініки, листопад 2026).
// Якщо для послуги тут є запис, сторінка показує його замість короткого опису та списку переваг.

type L = { uk: string; ru: string; en: string };

export interface ServiceExtra {
  lead: L;
  paragraphs: { uk: string[]; ru: string[]; en: string[] };
  photo?: { src: string; alt: L; position?: string };
  benefitsTitle: L;
  benefits: { lead?: L; text: L }[];
  closing?: L;
  doctor?: { slug: string; role?: L; quote?: L; stats?: { value: string; label: L }[] };
}

export const serviceExtras: Record<string, ServiceExtra> = {
  katarakta: {
    lead: {
      uk: 'Сучасна хірургія катаракти — можливість повернути чіткість зору та знову бачити світ у деталях.',
      ru: 'Современная хирургия катаракты — возможность вернуть чёткость зрения и снова видеть мир в деталях.',
      en: 'Modern cataract surgery is a chance to restore clear vision and see the world in detail again.',
    },
    paragraphs: {
      uk: [
        'В Ophthalmology Group ми проводимо операції з видалення катаракти методом факоемульсифікації — сучасною малотравматичною методикою, що дозволяє видалити помутнілий кришталик через мікророзріз та імплантувати на його місце штучну інтраокулярну лінзу (ІОЛ).',
        'Для кожного пацієнта підбирається індивідуальне рішення з урахуванням особливостей зору, стану очей та способу життя.',
        'Ми пропонуємо широкий вибір інтраокулярних лінз від провідних виробників, зокрема Alcon, Elon, Bunny Lens, та інших.',
      ],
      ru: [
        'В Ophthalmology Group мы проводим операции по удалению катаракты методом факоэмульсификации — современной малотравматичной методикой, которая позволяет удалить помутневший хрусталик через микроразрез и имплантировать на его место искусственную интраокулярную линзу (ИОЛ).',
        'Для каждого пациента подбирается индивидуальное решение с учётом особенностей зрения, состояния глаз и образа жизни.',
        'Мы предлагаем широкий выбор интраокулярных линз от ведущих производителей, в частности Alcon, Elon, Bunny Lens и других.',
      ],
      en: [
        'At Ophthalmology Group we remove cataracts by phacoemulsification, a modern minimally invasive technique that removes the clouded lens through a micro-incision and replaces it with an artificial intraocular lens (IOL).',
        'For every patient we choose an individual solution based on their vision, the condition of their eyes and their lifestyle.',
        'We offer a wide choice of intraocular lenses from leading manufacturers, including Alcon, Elon, Bunny Lens and others.',
      ],
    },
    photo: {
      src: '/images/services/katarakta-serdyuk.jpg',
      alt: { uk: 'Професор Сердюк Валерій Миколайович', ru: 'Профессор Сердюк Валерий Николаевич', en: 'Professor Valeriy Serdyuk' },
      position: '50% 22%',
    },
    benefitsTitle: { uk: 'Переваги сучасного лікування', ru: 'Преимущества современного лечения', en: 'Benefits of modern treatment' },
    benefits: [
      { lead: { uk: 'Мікророзріз 2,2 мм', ru: 'Микроразрез 2,2 мм', en: '2.2 mm micro-incision' }, text: { uk: 'мінімальне хірургічне втручання.', ru: 'минимальное хирургическое вмешательство.', en: 'minimal surgical intervention.' } },
      { lead: { uk: 'Індивідуальний підбір ІОЛ', ru: 'Индивидуальный подбор ИОЛ', en: 'Individual IOL selection' }, text: { uk: 'вибір лінзи відповідно до потреб пацієнта.', ru: 'выбор линзы в соответствии с потребностями пациента.', en: 'a lens chosen to match the patient’s needs.' } },
      { lead: { uk: 'Сучасна технологія факоемульсифікації', ru: 'Современная технология факоэмульсификации', en: 'Modern phacoemulsification technology' }, text: { uk: 'точність та контроль на кожному етапі операції.', ru: 'точность и контроль на каждом этапе операции.', en: 'precision and control at every stage of the operation.' } },
      { lead: { uk: 'Додому в день операції', ru: 'Домой в день операции', en: 'Home on the day of surgery' }, text: { uk: 'у більшості випадків пацієнт може повернутися додому в день операції.', ru: 'в большинстве случаев пациент может вернуться домой в день операции.', en: 'in most cases the patient can go home on the day of the surgery.' } },
      { lead: { uk: 'Післяопераційний супровід', ru: 'Послеоперационное сопровождение', en: 'Post-operative care' }, text: { uk: 'контроль відновлення та рекомендації лікаря.', ru: 'контроль восстановления и рекомендации врача.', en: 'monitoring of recovery and the doctor’s recommendations.' } },
    ],
    doctor: {
      slug: 'serdyuk',
      stats: [
        { value: '30+', label: { uk: 'років досвіду роботи', ru: 'лет опыта работы', en: 'years of experience' } },
        { value: '15 000+', label: { uk: 'проведених операцій', ru: 'проведённых операций', en: 'operations performed' } },
      ],
      quote: {
        uk: '«Для мене важливо не лише провести операцію, а й підібрати оптимальне рішення для кожного пацієнта з урахуванням стану очей та його потреб.»',
        ru: '«Для меня важно не только провести операцию, но и подобрать оптимальное решение для каждого пациента с учётом состояния глаз и его потребностей.»',
        en: '“For me it is important not only to perform the surgery, but to find the best solution for each patient, taking into account the condition of their eyes and their needs.”',
      },
    },
  },

  'dytiacha-oftalmologiya': {
    lead: {
      uk: 'Здоровий зір дитини — важлива складова її розвитку та пізнання світу.',
      ru: 'Здоровое зрение ребёнка — важная составляющая его развития и познания мира.',
      en: 'A child’s healthy vision is an important part of their development and of discovering the world.',
    },
    paragraphs: {
      uk: [
        'Зір відіграє важливу роль у навчанні, розвитку та щоденній активності дитини. Саме тому важливо своєчасно перевіряти його стан, виявляти можливі порушення та контролювати розвиток зорової системи.',
        'В Ophthalmology Group ми проводимо комплексну діагностику зору у дітей різного віку, допомагаємо виявляти та лікувати офтальмологічні захворювання, підбираємо необхідну корекцію та розробляємо індивідуальні програми спостереження.',
        'Працюємо з такими порушеннями, як короткозорість, далекозорість, астигматизм, амбліопія та косоокість.',
        'Обстеження проходить з урахуванням віку та індивідуальних особливостей маленького пацієнта, у спокійній та доброзичливій атмосфері.',
      ],
      ru: [
        'Зрение играет важную роль в обучении, развитии и ежедневной активности ребёнка. Именно поэтому важно своевременно проверять его состояние, выявлять возможные нарушения и контролировать развитие зрительной системы.',
        'В Ophthalmology Group мы проводим комплексную диагностику зрения у детей разного возраста, помогаем выявлять и лечить офтальмологические заболевания, подбираем необходимую коррекцию и разрабатываем индивидуальные программы наблюдения.',
        'Работаем с такими нарушениями, как близорукость, дальнозоркость, астигматизм, амблиопия и косоглазие.',
        'Обследование проходит с учётом возраста и индивидуальных особенностей маленького пациента, в спокойной и доброжелательной атмосфере.',
      ],
      en: [
        'Vision plays an important role in a child’s learning, development and daily activity. That is why it is important to check it in time, detect possible problems and monitor the development of the visual system.',
        'At Ophthalmology Group we carry out comprehensive vision diagnostics for children of different ages, help detect and treat eye diseases, choose the necessary correction and develop individual follow-up programs.',
        'We work with conditions such as myopia, hyperopia, astigmatism, amblyopia and strabismus.',
        'The examination takes into account the age and individual characteristics of the young patient and takes place in a calm and friendly atmosphere.',
      ],
    },
    photo: {
      src: '/images/services/dytiacha-oftalmologiya.jpg',
      alt: { uk: 'Дитячий офтальмолог під час обстеження', ru: 'Детский офтальмолог во время обследования', en: 'Pediatric ophthalmologist during an examination' },
      position: '50% 30%',
    },
    benefitsTitle: { uk: 'Чому батьки обирають Ophthalmology Group?', ru: 'Почему родители выбирают Ophthalmology Group?', en: 'Why do parents choose Ophthalmology Group?' },
    benefits: [
      { lead: { uk: 'Комплексна діагностика', ru: 'Комплексная диагностика', en: 'Comprehensive diagnostics' }, text: { uk: 'оцінка стану зорової системи дитини.', ru: 'оценка состояния зрительной системы ребёнка.', en: 'assessment of the condition of the child’s visual system.' } },
      { lead: { uk: 'Контроль короткозорості', ru: 'Контроль близорукости', en: 'Myopia control' }, text: { uk: 'спостереження за динамікою та підбір методів контролю її прогресування.', ru: 'наблюдение за динамикой и подбор методов контроля её прогрессирования.', en: 'monitoring its progression and choosing methods to control it.' } },
      { lead: { uk: 'Індивідуальне лікування', ru: 'Индивидуальное лечение', en: 'Individual treatment' }, text: { uk: 'допомога дітям з амбліопією, косоокістю та іншими порушеннями зору.', ru: 'помощь детям с амблиопией, косоглазием и другими нарушениями зрения.', en: 'help for children with amblyopia, strabismus and other vision disorders.' } },
      { lead: { uk: 'Підбір корекції', ru: 'Подбор коррекции', en: 'Vision correction' }, text: { uk: 'окуляри та контактні лінзи відповідно до віку й потреб дитини.', ru: 'очки и контактные линзы в соответствии с возрастом и потребностями ребёнка.', en: 'glasses and contact lenses suited to the child’s age and needs.' } },
      { lead: { uk: 'Апаратне лікування', ru: 'Аппаратное лечение', en: 'Hardware-based treatment' }, text: { uk: 'за показаннями та відповідно до призначень лікаря.', ru: 'по показаниям и в соответствии с назначениями врача.', en: 'when indicated and as prescribed by the doctor.' } },
    ],
    closing: {
      uk: 'Дбайте про зір дитини сьогодні — для її впевненого завтра.',
      ru: 'Заботьтесь о зрении ребёнка сегодня — для его уверенного завтра.',
      en: 'Take care of your child’s vision today for a confident tomorrow.',
    },
    doctor: { slug: 'yavorska' },
  },

  'diagnostyka-zoru': {
    lead: {
      uk: 'Бачити чітко — це не лише добре розрізняти предмети. Це знати, що здоров’я ваших очей під контролем.',
      ru: 'Видеть чётко — это не только хорошо различать предметы. Это знать, что здоровье ваших глаз под контролем.',
      en: 'Seeing clearly is not only about telling objects apart. It is knowing that the health of your eyes is under control.',
    },
    paragraphs: {
      uk: [
        'В Ophthalmology Group ми проводимо комплексне обстеження зорової системи, щоб оцінити стан очей, виявити можливі порушення та захворювання на ранніх стадіях і визначити подальшу тактику спостереження або лікування.',
        'Діагностика проводиться на сучасному обладнанні провідних світових виробників Topcon, Carl Zeiss та інших.',
        'Під час обстеження лікар оцінює гостроту зору, рефракцію, внутрішньоочний тиск, стан переднього та заднього відділів ока. За необхідності призначаються додаткові дослідження, зокрема оптична когерентна томографія (ОКТ).',
        'За результатами пацієнт отримує детальний висновок офтальмолога, рекомендації та індивідуальний план подальших дій.',
      ],
      ru: [
        'В Ophthalmology Group мы проводим комплексное обследование зрительной системы, чтобы оценить состояние глаз, выявить возможные нарушения и заболевания на ранних стадиях и определить дальнейшую тактику наблюдения или лечения.',
        'Диагностика проводится на современном оборудовании ведущих мировых производителей Topcon, Carl Zeiss и других.',
        'Во время обследования врач оценивает остроту зрения, рефракцию, внутриглазное давление, состояние переднего и заднего отделов глаза. При необходимости назначаются дополнительные исследования, в частности оптическая когерентная томография (ОКТ).',
        'По результатам пациент получает детальное заключение офтальмолога, рекомендации и индивидуальный план дальнейших действий.',
      ],
      en: [
        'At Ophthalmology Group we carry out a comprehensive examination of the visual system to assess the condition of the eyes, detect possible disorders and diseases at an early stage and decide on further follow-up or treatment.',
        'Diagnostics are performed on modern equipment from leading world manufacturers Topcon, Carl Zeiss and others.',
        'During the examination the doctor assesses visual acuity, refraction, intraocular pressure and the condition of the anterior and posterior segments of the eye. If necessary, additional tests are prescribed, including optical coherence tomography (OCT).',
        'Afterwards the patient receives a detailed ophthalmologist’s report, recommendations and an individual plan of further action.',
      ],
    },
    photo: {
      src: '/images/services/diagnostyka-zoru.jpg',
      alt: { uk: 'Комплексна діагностика зору на сучасному обладнанні', ru: 'Комплексная диагностика зрения на современном оборудовании', en: 'Comprehensive vision diagnostics on modern equipment' },
      position: '50% 50%',
    },
    benefitsTitle: { uk: 'Переваги комплексної діагностики', ru: 'Преимущества комплексной диагностики', en: 'Benefits of comprehensive diagnostics' },
    benefits: [
      { lead: { uk: 'Повноцінне обстеження', ru: 'Полноценное обследование', en: 'Full examination' }, text: { uk: 'оцінка основних структур та функцій зорової системи.', ru: 'оценка основных структур и функций зрительной системы.', en: 'assessment of the main structures and functions of the visual system.' } },
      { lead: { uk: 'Сучасне обладнання', ru: 'Современное оборудование', en: 'Modern equipment' }, text: { uk: 'діагностичні технології Topcon, Carl Zeiss та інших виробників.', ru: 'диагностические технологии Topcon, Carl Zeiss и других производителей.', en: 'diagnostic technology from Topcon, Carl Zeiss and other manufacturers.' } },
      { lead: { uk: 'Тривалість 1–2 години', ru: 'Длительность 1–2 часа', en: 'Duration of 1–2 hours' }, text: { uk: 'достатньо часу для необхідних досліджень та консультації.', ru: 'достаточно времени для необходимых исследований и консультации.', en: 'enough time for the necessary tests and consultation.' } },
      { lead: { uk: 'Детальний висновок лікаря', ru: 'Детальное заключение врача', en: 'Detailed doctor’s report' }, text: { uk: 'зрозумілі результати обстеження та рекомендації.', ru: 'понятные результаты обследования и рекомендации.', en: 'clear examination results and recommendations.' } },
      { lead: { uk: 'Індивідуальний підхід', ru: 'Индивидуальный подход', en: 'Individual approach' }, text: { uk: 'додаткові дослідження відповідно до показань.', ru: 'дополнительные исследования в соответствии с показаниями.', en: 'additional tests according to indications.' } },
    ],
  },
};
