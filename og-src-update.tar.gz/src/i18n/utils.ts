import uk from './uk.json';
import ru from './ru.json';
import en from './en.json';

export type Locale = 'uk' | 'ru' | 'en';

const translations: Record<Locale, Record<string, any>> = { uk, ru, en };

/** Get a translated string by dot-separated key */
export function t(locale: Locale, key: string): string {
  const keys = key.split('.');
  let value: any = translations[locale];
  for (const k of keys) {
    value = value?.[k];
    if (value === undefined) return key;
  }
  return typeof value === 'string' ? value : key;
}

/** Build a localized path */
export function localePath(locale: Locale, path: string = '/'): string {
  const clean = path.startsWith('/') ? path : `/${path}`;
  return `/${locale}${clean === '/' ? '/' : clean}`;
}

/** Get alternate language links for hreflang tags */
export function getAlternates(path: string): { locale: Locale; href: string }[] {
  return (['uk', 'ru', 'en'] as Locale[]).map((locale) => ({
    locale,
    href: translatePath(path, locale),
  }));
}

/**
 * Same page in another language: swaps the locale prefix AND the localized
 * section slug (e.g. /ru/uslugi/katarakta/ -> /uk/poslugy/katarakta/).
 */
export function translatePath(path: string, target: Locale): string {
  const stripped = path.replace(/^\/(uk|ru|en)(?=\/|$)/, '') || '/';
  const parts = stripped.split('/');
  const first = parts[1];
  if (first) {
    for (const routes of Object.values(localeRoutes)) {
      const key = (Object.keys(routes) as (keyof typeof routes)[]).find((k) => routes[k] === first);
      if (key) { parts[1] = localeRoutes[target][key]; break; }
    }
  }
  return localePath(target, parts.join('/') || '/');
}

/** Map locale to path segments for pages */
export const localeRoutes = {
  uk: {
    about: 'pro-nas',
    doctors: 'likari',
    services: 'poslugy',
    prices: 'tsiny',
    reviews: 'vidguky',
    equipment: 'obladnannya',
    news: 'novyny',
    contacts: 'kontakty',
    results: 'rezultaty',
    thanks: 'dyakuyemo',
  },
  ru: {
    about: 'o-nas',
    doctors: 'vrachi',
    services: 'uslugi',
    prices: 'tseny',
    reviews: 'otzyvy',
    equipment: 'oborudovanie',
    news: 'novosti',
    contacts: 'kontakty',
    results: 'rezultaty',
    thanks: 'spasibo',
  },
  en: {
    about: 'about',
    doctors: 'doctors',
    services: 'services',
    prices: 'prices',
    reviews: 'reviews',
    equipment: 'equipment',
    news: 'news',
    contacts: 'contacts',
    results: 'results',
    thanks: 'thank-you',
  },
} as const;

/** Get navigation items for a locale */
export function getNavItems(locale: Locale) {
  const routes = localeRoutes[locale];
  return [
    { label: t(locale, 'nav.about'), href: localePath(locale, `/${routes.about}`) },
    { label: t(locale, 'nav.doctors'), href: localePath(locale, `/${routes.doctors}`) },
    { label: t(locale, 'nav.services'), href: localePath(locale, `/${routes.services}`) },
    { label: t(locale, 'nav.prices'), href: localePath(locale, `/${routes.prices}`) },
    { label: t(locale, 'nav.reviews'), href: localePath(locale, `/${routes.reviews}`) },
    { label: t(locale, 'nav.equipment'), href: localePath(locale, `/${routes.equipment}`) },
    { label: t(locale, 'nav.news'), href: localePath(locale, `/${routes.news}`) },
    { label: t(locale, 'nav.contacts'), href: localePath(locale, `/${routes.contacts}`) },
  ];
}
